namespace Lab1
{
    internal class HighScore
    {
        public string Name { get; set; }
        public int Trials { get; set; }
    }
}
